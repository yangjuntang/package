The name of code is ��LMR algorithm��. 

The title of the manuscript is "A New Dilatancy Model Based on PLMR Algorithm and Big Data Characteristic of Dilatancy"

Corresponding author:YUANXUE LIU
E-mail: lyuanxue@vip.sina.com
Co-authors: 
JUNTANG YANG
E-mail1: yangjt12605@aliyun.com
Name2��SHAOQI HE
E-mail2: hesqlq@outlook.com

The  address is North Road of University Town,Shapingba District, Chongqing, China. 

The experiment is completed in HADOOP cluster environment. The cluster consists of four PCs, one PC as master, the other three PCs as slave 1, slave 2 and slave 3, respectively. The hardware environment of the PC is 3.4 GHz Intel i5-7500 CPU and 16GB memory. The software environment is Ubuntu 14.04 operating system and Hadoop 2.6.1 distributed computing framework.  